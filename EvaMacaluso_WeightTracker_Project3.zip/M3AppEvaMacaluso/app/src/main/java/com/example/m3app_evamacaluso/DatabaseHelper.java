package com.example.m3app_evamacaluso;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database info
    private static final String DATABASE_NAME = "M3App.db";
    private static final int DATABASE_VERSION = 1;

    // Users table (login)
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Weight tracker table (generic records table for now)
    public static final String TABLE_RECORDS = "records";
    public static final String COL_RECORD_ID = "record_id";
    public static final String COL_RECORD_NAME = "record_name";   // use for date
    public static final String COL_RECORD_VALUE = "record_value"; // use for weight

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE, "
                + COL_PASSWORD + " TEXT)";

        // Create weight records table
        String createRecordsTable = "CREATE TABLE " + TABLE_RECORDS + " ("
                + COL_RECORD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_RECORD_NAME + " TEXT, "
                + COL_RECORD_VALUE + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createRecordsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECORDS);
        onCreate(db);
    }

    // =========================
    // USER LOGIN / REGISTER
    // =========================

    // Check if username already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Insert new user account
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Check login credentials
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean valid = cursor.getCount() > 0;
        cursor.close();
        return valid;
    }

    // =========================
    // WEIGHT TRACKER CRUD
    // =========================

    // CREATE - add weight entry
    public boolean insertWeightEntry(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_RECORD_NAME, date);
        values.put(COL_RECORD_VALUE, weight);

        long result = db.insert(TABLE_RECORDS, null, values);
        return result != -1;
    }

    // READ - get all entries
    public Cursor getAllWeightEntries() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_RECORDS, null);
    }

    // UPDATE - update entry by id
    public boolean updateWeightEntry(String id, String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_RECORD_NAME, date);
        values.put(COL_RECORD_VALUE, weight);

        int rows = db.update(TABLE_RECORDS, values, COL_RECORD_ID + "=?", new String[]{id});
        return rows > 0;
    }

    // DELETE - delete entry by id
    public boolean deleteWeightEntry(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_RECORDS, COL_RECORD_ID + "=?", new String[]{id});
        return rows > 0;
    }
}